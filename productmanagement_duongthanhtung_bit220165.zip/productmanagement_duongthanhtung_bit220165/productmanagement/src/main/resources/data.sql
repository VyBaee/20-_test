-- Insert sample data into category table
INSERT INTO category (name) VALUES ('Electronics');
INSERT INTO category (name) VALUES ('Furniture');
INSERT INTO category (name) VALUES ('Clothing');

-- Insert sample data into product table
INSERT INTO product (name, price, discount_price, image, description, category_id, status) VALUES
('Smartphone', 299.99, 249.99, 'http://example.com/smartphone.jpg', 'Latest model smartphone with advanced features', 1, 'Available'),
('Sofa', 499.99, 449.99, 'http://example.com/sofa.jpg', 'Comfortable 3-seater sofa with modern design', 2, 'Available'),
('T-shirt', 19.99, 14.99, 'http://example.com/tshirt.jpg', 'Cotton T-shirt available in various colors', 3, 'Out of Stock');
